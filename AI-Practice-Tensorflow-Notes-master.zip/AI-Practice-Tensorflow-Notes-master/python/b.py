#coding:utf-8
age=input("输入你的年龄\n")
if age>18:
    print "大于十八岁"
    print "你成年了"
else:
    print "小于等于十八岁"
    print "还未成年"

