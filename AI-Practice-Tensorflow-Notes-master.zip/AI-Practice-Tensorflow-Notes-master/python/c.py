#coding:utf-8
num=input("please input your class number:")
if num==1 or num==2:
    print "class room 302"
elif num==3:
    print "class room 303"
elif num==4:
    print "class room 304"
else:
    print "class room 305"
